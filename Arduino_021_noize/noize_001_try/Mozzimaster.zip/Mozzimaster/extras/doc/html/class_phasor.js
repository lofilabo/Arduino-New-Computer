var class_phasor =
[
    [ "Phasor", "class_phasor.html#a147c4c3aa7506c3da800e6cc77deb4ac", null ],
    [ "next", "class_phasor.html#a696198206182acaed5cf27fef226118d", null ],
    [ "phaseIncFromFreq", "class_phasor.html#a6e7656824ae72aea09ce851c7b340eaf", null ],
    [ "set", "class_phasor.html#ad9e0eceb175bca6b2b79130fd9c4f4ef", null ],
    [ "setFreq", "class_phasor.html#afc6106c648bddb5f2f084b8f34216b0f", null ],
    [ "setFreq", "class_phasor.html#a81f1976ebb4a91f66f26674efca52072", null ],
    [ "setPhaseInc", "class_phasor.html#adf134d4e4ce960e4c773830fd8467e4b", null ]
];