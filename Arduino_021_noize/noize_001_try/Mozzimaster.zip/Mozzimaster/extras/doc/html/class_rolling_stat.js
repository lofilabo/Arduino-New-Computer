var class_rolling_stat =
[
    [ "RollingStat", "class_rolling_stat.html#a98c3f767391db80b8ad59ca53c1e6a94", null ],
    [ "getMean", "class_rolling_stat.html#a8521a53cde7c5d28ac9c375aaee3a972", null ],
    [ "getStandardDeviation", "class_rolling_stat.html#a234ab1d244e4b392056fcaa1fc1e4fc4", null ],
    [ "getVariance", "class_rolling_stat.html#a3e7e5f706e3b5ac2496f14b7b639775d", null ],
    [ "update", "class_rolling_stat.html#a85750e78ac282caec24408dce6e78201", null ],
    [ "update", "class_rolling_stat.html#a6f7b384ab338da5ba10200fbce7f2eb0", null ]
];