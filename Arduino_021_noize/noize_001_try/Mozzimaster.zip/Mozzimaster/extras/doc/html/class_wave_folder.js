var class_wave_folder =
[
    [ "WaveFolder", "class_wave_folder.html#a3be0f0b5ee86082e44b0b88cf5b9ac2f", null ],
    [ "next", "class_wave_folder.html#af80790f963340c3b7f289933a28cbfc5", null ],
    [ "setHighLimit", "class_wave_folder.html#a2103be1ef91d0a3e4d896eabdad83fc7", null ],
    [ "setLimits", "class_wave_folder.html#af06cfae975014be2651966519df0f0cd", null ],
    [ "setLowLimit", "class_wave_folder.html#ae8522fd82e949e8115193905bcf5b01c", null ]
];